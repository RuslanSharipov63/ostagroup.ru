
	<div class="flex-container">
	<div>
			<table class="one">
				<tr>
				<td>ТЕЛ.: &nbsp; <a href="tel:+79272971733">+7 927 297 17 33</a> &nbsp; E-MAIL.: &nbsp; <a href="mailto:ostagroup.ru@gmail.com">ostagroup.ru@gmail.com</a> 
			    </td>
			    <td><img src="images/logoza.jpg" alt="Логотип"/></td>
				</tr>
			</table>
	</div>
		<div>
				<table class="two">
				   <tr>
				 <th><a href="index.html">Главная</a></th>
				 <th><a href="onas.html">О нас</a></th>
				 <th><a href="uslugi.html">Услуги</a></th>
				 
				   </tr>
				</table>
		</div>
		</div>
		
		
		
	<div class="uslugi">
	   <div><a href="sz.php"/>Создание сайтов</a></div>
	    <div><a href="srs.php"/>Сопровождение и развитие сайтов</a></div>
		<div><a href="rvi.php"/>Реклама в интернете</a></div>
		</div>
		<div class="uslugi2">
	   <div><a href="analit.php"/>Аналитика</a></div>
	    <div><a href="analitk.php"/>Анализ конкурентов</a></div>
		<div><a href="pvss.php"/>Продвижение в социальных сетях (SMM)</a></div>
	</div>
		
		
	
    