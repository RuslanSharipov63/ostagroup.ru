<div class="footer">
				  <div><ul><li>Контакты</li> 
				  <li>+7 927 297 17 33</li>
				  <li>ostagroup.ru@gmail.com</li>
				  </ul></div>
				  <div><a href="tel:+79272971733">позвоните нам</a> </div>
				  <div><a href="mailto:ostagroup.ru@gmail.com">Напишите нам</a></div>

		</div>